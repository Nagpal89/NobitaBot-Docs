from __future__ import annotations

import os
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any

import discord
from discord.ext import commands

try:
    import config  # type: ignore
except Exception:  # config may be packaged under another module in some deployments
    config = None  # type: ignore

try:
    import psutil  # type: ignore
except Exception:
    psutil = None  # type: ignore

from .common import INVITE_URL, PARTNER_URL

SUPPORT_URL = os.getenv("NOBITA_SUPPORT_URL", "").strip()


def _setting_color() -> discord.Color:
    """Use the project's configured custom embed color where available."""
    candidates: list[Any] = []
    if config is not None:
        for name in (
            "EMBED_COLOR", "CUSTOM_EMBED_COLOR", "DEFAULT_EMBED_COLOR",
            "BOT_EMBED_COLOR", "EMBED_COLOUR", "COLOR", "COLOUR",
        ):
            candidates.append(getattr(config, name, None))
        # Some projects keep settings in a nested dictionary.
        for container_name in ("EMBED", "EMBED_CONFIG", "BOT_CONFIG", "CONFIG"):
            value = getattr(config, container_name, None)
            if isinstance(value, dict):
                for name in ("color", "colour", "embed_color", "embed_colour"):
                    candidates.append(value.get(name))
    candidates.extend((os.getenv("NOBITA_EMBED_COLOR"), os.getenv("EMBED_COLOR")))

    for value in candidates:
        if value is None or value == "":
            continue
        try:
            if isinstance(value, discord.Color):
                return value
            if isinstance(value, int):
                return discord.Color(value & 0xFFFFFF)
            raw = str(value).strip().lower().replace("#", "")
            if raw.startswith("0x"):
                raw = raw[2:]
            return discord.Color(int(raw, 16))
        except (TypeError, ValueError):
            continue
    return discord.Color.blurple()


def _duration(seconds: float) -> str:
    total = max(0, int(seconds))
    weeks, total = divmod(total, 604800)
    days, total = divmod(total, 86400)
    hours, total = divmod(total, 3600)
    minutes, seconds = divmod(total, 60)
    parts: list[str] = []
    if weeks:
        parts.append(f"{weeks}w")
    if days or weeks:
        parts.append(f"{days}d")
    parts.extend((f"{hours}h", f"{minutes}m", f"{seconds}s"))
    return " ".join(parts)


class AboutView(discord.ui.View):
    """Always show all three actions, even if optional URLs aren't configured yet."""

    def __init__(self, bot: commands.Bot) -> None:
        super().__init__(timeout=180)
        self.bot = bot

        # Link buttons require valid URLs. Use real link buttons when configured;
        # otherwise show a normal button that explains the missing configuration.
        if SUPPORT_URL:
            self.add_item(discord.ui.Button(label="Support Server", style=discord.ButtonStyle.link, url=SUPPORT_URL))
        else:
            self.add_item(_MissingLinkButton(label="Support Server", setting="NOBITA_SUPPORT_URL"))

        invite_url = INVITE_URL
        if not invite_url and bot.user:
            invite_url = discord.utils.oauth_url(bot.user.id, permissions=discord.Permissions.none())
        if invite_url:
            self.add_item(discord.ui.Button(label="Invite Me", style=discord.ButtonStyle.link, url=invite_url))
        else:
            self.add_item(_MissingLinkButton(label="Invite Me", setting="NOBITA_INVITE_URL"))

        if PARTNER_URL:
            self.add_item(discord.ui.Button(label="Partner", style=discord.ButtonStyle.link, url=PARTNER_URL))
        else:
            self.add_item(_MissingLinkButton(label="Partner", setting="NOBITA_PARTNER_URL"))


class _MissingLinkButton(discord.ui.Button):
    def __init__(self, *, label: str, setting: str) -> None:
        super().__init__(label=label, style=discord.ButtonStyle.secondary)
        self.setting = setting

    async def callback(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            f"This link isn't configured yet. Set `{self.setting}` in your hosting environment, then restart Nobita.",
            ephemeral=True,
        )


class AboutCog(commands.Cog):
    """Live statistics and information about Nobita."""

    CATEGORY = "Nobita Misc"

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.started_at = time.monotonic()
        self.messages_seen = 0
        self.commands_global = 0
        self.commands_by_server: dict[int, int] = {}
        self.commands_by_user: dict[int, int] = {}
        self.message_times: deque[float] = deque()

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot:
            return
        self.messages_seen += 1
        now = time.monotonic()
        self.message_times.append(now)
        self._trim_message_times(now)

    @commands.Cog.listener()
    async def on_command_completion(self, ctx: commands.Context) -> None:
        self.commands_global += 1
        if ctx.guild is not None:
            self.commands_by_server[ctx.guild.id] = self.commands_by_server.get(ctx.guild.id, 0) + 1
        self.commands_by_user[ctx.author.id] = self.commands_by_user.get(ctx.author.id, 0) + 1

    def _trim_message_times(self, now: float) -> None:
        while self.message_times and now - self.message_times[0] > 60:
            self.message_times.popleft()

    async def _database_latency_ms(self) -> float | None:
        pool = getattr(self.bot, "db_pool", None)
        if pool is None:
            return None
        started = time.perf_counter()
        try:
            async with pool.acquire() as connection:
                await connection.fetchval("SELECT 1")
            return (time.perf_counter() - started) * 1000
        except Exception:
            return None

    @commands.command(name="about", description="Show Nobita's statistics and information.")
    async def about(self, ctx: commands.Context) -> None:
        guilds = list(self.bot.guilds)
        total_members = sum(g.member_count or 0 for g in guilds)
        cached_members = len(self.bot.users)
        text_channels = sum(1 for g in guilds for c in g.channels if isinstance(c, discord.TextChannel))
        voice_channels = sum(1 for g in guilds for c in g.channels if isinstance(c, (discord.VoiceChannel, discord.StageChannel)))
        total_channels = sum(len(g.channels) for g in guilds)
        now = time.monotonic()
        self._trim_message_times(now)
        ipm = len(self.message_times) / 60.0
        db_latency = await self._database_latency_ms()
        db_text = f"{db_latency:.2f} ms" if db_latency is not None else "Unavailable"
        gateway_text = f"{self.bot.latency * 1000:.1f} ms" if self.bot.latency is not None else "Unavailable"

        if psutil is not None:
            try:
                process = psutil.Process(os.getpid())
                ram_mb = process.memory_info().rss / (1024 * 1024)
                total_ram_mb = psutil.virtual_memory().total / (1024 * 1024)
                cpu_percent = process.cpu_percent(interval=None)
                system_text = f"**RAM:** {ram_mb:,.0f} / {total_ram_mb:,.0f} MB\n**CPU:** {cpu_percent:.1f}% used"
            except Exception:
                system_text = "RAM/CPU metrics unavailable"
        else:
            system_text = "Install `psutil` to display RAM and CPU usage."

        embed = discord.Embed(
            title="Nobita's Statistics and Information",
            color=_setting_color(),
            timestamp=datetime.now(timezone.utc),
        )
        embed.add_field(name="Servers", value=f"**{len(guilds):,} total** · {self.bot.shard_count or 1} shard(s)", inline=False)
        embed.add_field(name="Uptime", value=f"{_duration(now - self.started_at)} · {self.messages_seen:,} messages seen since restart", inline=False)
        embed.add_field(name="Members", value=f"**{total_members:,} total** · {cached_members:,} cached users", inline=False)
        embed.add_field(name="Channels", value=f"**{total_channels:,} total** · {text_channels:,} text · {voice_channels:,} voice", inline=False)
        guild_count = self.commands_by_server.get(ctx.guild.id, 0) if ctx.guild else 0
        user_count = self.commands_by_user.get(ctx.author.id, 0)
        embed.add_field(name="Total Commands Used", value=f"**{self.commands_global:,} globally** · {guild_count:,} in this server · {user_count:,} by you", inline=False)
        embed.add_field(name="Stats", value=f"**Ping:** {gateway_text} · **Database:** {db_text} · **IPM:** {ipm:.2f}", inline=False)
        embed.add_field(name="System", value=system_text, inline=False)
        embed.set_footer(text=f"Made with discord.py v{discord.__version__}")
        if self.bot.user:
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        await ctx.reply(embed=embed, view=AboutView(self.bot), mention_author=False)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(AboutCog(bot))
